# input cards
deck = [x for x in xrange(52)]
count = 1
new_deck = []

def shuffle_deck(card_deck, new_deck, count):
  # input cards for comaprison
  deck = [x for x in xrange(52)]
  
  # Looping over cards to shuffle
  for i, card in enumerate(card_deck):
    if i == 0:
      del card_deck[i]
      new_deck.append(card)
    elif i%2 == 0:
      del card_deck[i]
      card_deck.append(card)
    else:
      del card_deck[i]
      new_deck.append(card)
      
  # Checking for shuffle completion
  if card_deck == []:
    if new_deck == deck:
      print "number of shuffles required: ", count
    else:
      count += 1
      shuffle_deck(new_deck, card_deck, count)
  else:
    shuffle_deck(card_deck, new_deck, count)


shuffle_deck(deck, new_deck, count)
